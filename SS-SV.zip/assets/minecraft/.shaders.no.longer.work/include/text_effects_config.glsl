TEXT_EFFECT(0, 174, 174) {
	apply_skewing_movement(1);
    override_text_color(rgb(0, 168, 168));
    override_shadow_color(rgb(0, 27, 27));
    apply_outline(rgb(0, 27, 27));
	apply_shimmer(1, 1);
}

TEXT_EFFECT(88, 251, 88) {
    override_text_color(rgb(84, 251, 84));
    override_shadow_color(rgb(21, 64, 21));
    apply_outline(rgb(21, 64, 21));
	apply_shimmer(1, 1);
}

TEXT_EFFECT(168, 71, 71) {
    override_text_color(rgb(251, 84, 84));
    override_shadow_color(rgb(94, 28, 28));
    apply_outline(rgb(94, 28, 28));
	apply_shimmer(1, 1);
	apply_shaking_movement();
	apply_fire();
}

TEXT_EFFECT(165, 15, 121) {
    apply_waving_movement(0.5);
    apply_rainbow();
}

TEXT_EFFECT(59, 64, 50) {
    apply_waving_movement(0.5);
    apply_metalic(rgb(87,189,28));
	apply_shimmer(1, 1);
}

TEXT_EFFECT(0, 170, 4) {
	apply_shaking_movement();
    apply_outline(rgb(0, 64, 0));
}
	
TEXT_EFFECT(8, 8, 8) {
	apply_metalic(rgb(255, 162, 0));
	apply_shimmer();
}

TEXT_EFFECT(12, 12, 12) {
	apply_metalic(rgb(59, 193, 255));
	apply_shimmer();
}

TEXT_EFFECT(16, 16, 16) {
	apply_metalic(rgb(224, 224, 224));
	apply_shimmer();
}

TEXT_EFFECT(24, 24, 24) {
	apply_metalic(rgb(53, 173, 121));
	apply_shimmer();
}